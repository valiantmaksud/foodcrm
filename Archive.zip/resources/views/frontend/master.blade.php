@include('frontend._partials.header')

@yield('content')


@include('frontend._partials.footer')
