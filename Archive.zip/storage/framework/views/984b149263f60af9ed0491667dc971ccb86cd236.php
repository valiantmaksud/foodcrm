<?php $__env->startSection('custom-css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/hotels.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-4" style="margin-top: 150px !important">
        <h3>Choose your Item</h3>

        <?php $__currentLoopData = $menu_items->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row mt-4">
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4">
                        <div class="card" style="width: 100%">
                            <div class="card-body">
                                <img src="<?php echo e($menu->image ? asset($menu->image) : asset('frontend/images/Beef-Stew-Ugali-1.jpg')); ?>"
                                    alt="hotel1" />
                            </div>
                            <div class="card-footer">
                                <div class="name">
                                    <p class="text-center"><?php echo e($menu->name); ?></p>
                                </div>
                                <div class="descrptn">
                                    <p class="text-center"><?php echo e($menu->amount); ?></p>
                                </div>
                                <div class="rate text-center">
                                    <button type="button" class="btn btn-xs btn-info btn-rounded" data-toggle="modal"
                                        data-target="#add_cart<?php echo e($menu->id); ?>">
                                        Order
                                    </button>
                                </div>
                            </div>
                        </div>
                        <?php echo $__env->make('frontend.items.cart-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/MaD Files/Web Development/Local Clients/foodcrm/resources/views/frontend/items/items.blade.php ENDPATH**/ ?>