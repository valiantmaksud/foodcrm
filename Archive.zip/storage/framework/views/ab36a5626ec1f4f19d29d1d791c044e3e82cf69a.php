<?php $__env->startSection('custom-css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/hotels.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-4" style="margin-top: 150px !important">
        <h3>Choose your Menu</h3>

        <?php $__currentLoopData = $menus->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row mt-4">
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4">
                        <a href="<?php echo e(route('f.items', ['menu_id' => $menu->id])); ?>">
                            <div class="card" style="width: 100%">
                                <div class="card-body">
                                    <img src="<?php echo e($menu->image ? asset($menu->image) : asset('frontend/images/Beef-Stew-Ugali-1.jpg')); ?>"
                                        alt="hotel1" />
                                </div>
                                <div class="card-footer">
                                    <div class="name">
                                        <p class="text-center"><?php echo e($menu->name); ?></p>
                                    </div>
                                    <div class="descrptn">
                                        
                                    </div>
                                    <div class="rate text-center">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star" style="color:gray"></i>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/MaD Files/Web Development/Local Clients/foodcrm/resources/views/frontend/menus.blade.php ENDPATH**/ ?>